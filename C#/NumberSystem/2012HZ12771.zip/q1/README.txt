Steps to execute this assignment:
*********************************

Since this is a C# solution, we have a readymade executable file, NumberSystem.exe. It is  present in the same directory as this ReadMe file. 

1.Just execute it with the following line

mono NumberSystem.exe ./files/File1.txt ./files/File2.txt 3 ./files/File3.txt 

The arguments to NumberSystem.exe are separated by an empty space. 

In the above command the File1.txt, File2.txt are present in the directory called files. The file File3.txt would be the file into which the system would write the output. 

The number -- 3 -- is k.

The filenames could be any valid filepath of the execution environment. 

Once the command is executed, a text 'Press enter to exit' would be displayed. 

2. Press enter and exit. 

This assumes that mono is installed on the execution machine(labserver has it).

ASSUMPTIONS:
************

The system is based on some assumptions.These are laid out in the NumberSystem/Program.cs file.

/*Assumptions:
         * This system is based on the following assumptions.
         * 1. The numbers in the input file are all valid. Program doesnt check for validity
         *        Validity means - if a number is of a valid base(base <= the base of the system), 
         *                          then it is expressed using symbols of that base only.
         *         
         * 2.If any number is having a base greater than the base of the system, the system just shuts down. 
         * 3.If any number is expressed using symbols which the system doesnt understand, the system just shuts down.  
         * 4.If any of the file is not found in the given path, the system shuts down. 
         * 5.That k would be a valid integer and greater than 0.
         */
