Steps to execute this assignment:
*********************************

Could not differentiate between q1 and q2. So both go into the same solution. Please kindly consider this.

Since this is a C# solution, we have a readymade executable file, ColouredGraph.exe. It is  present in the same directory as this ReadMe file. 

1.Just execute it with the following line. All the execution commands below are valid

mono ColouredGraph.exe ./files/InputFile.txt ./files/OutputFile.txt  -- This writes the output to the outputfile indicated

mono ColouredGraph.exe ./files/InputFile.txt  -- This writes the output to the console

mono ColouredGraph.exe ./files/InputFile.txt ./files/OutputFile.txt 1 -- This writes the output to the outputfile indicated and apart from sorting graph by degree,also additionally sorts the adjacentvertices list of each node

The arguments to ColouredGraph.exe are separated by an empty space. 

In the above command the InputFile.txt is present in the directory called files. 
The file OutputFile.txt would be the file into which the system would write the output. This would also be present in the files folder.

There seemed to be an ambiguity with respect to sorting adjacent nodes or not. So, am doing both. If the third argument in the command line is 
- 1 - (numeric one), then the adjacent nodes list is also sorted, else, only the graph is sorted based on the degree.

The filenames could be any valid filepath of the execution environment. 

Once the command is executed,if an output file is mentioned, a text 'The graph has been written to the output file specified' would be displayed. 
Else, the graph would be displayed. Press any key to exit. 

2. Press any key and exit.

This assumes that mono is installed on the execution machine(labserver has it).

ASSUMPTIONS:
************

The system is based on some assumptions.These are laid out in the ColouredGraph/Driver.cs file.

	/* Assumptions:
         * This system is based on the following assumptions.
         * 1.The input/output file path is a valid path. No check is introduced to verify its validity. 
         *      If an invalid path is entered, then the system exits with an error message
         * 2.The input file is well-formed. No check is made to ensure that the first line is actually a number. 
         *     System shuts down throwing an error if its not. 
         * 3. The input file doesnt specify edges which lead to having more than the vertices present in the first line of the file. 
         *      If that is not the case, the system shuts down flagging an error.
         * 4. All the edges mentioned in the file are valid numbers only. The system doesnt check for the validity of the edge data. Assumes to be numbers.
         * 5. All the edges are mentioned. Since this is an undirected graph, an edge 1,2  also indicates implicitly the existence of edge 2,1. But this 
         *      implementation ignores this implicit assumption but rather expects the input file to provide all the edges i.e. 1,2 and also 2,1
         * 6. Assuming worst case scenario of a complete graph where all sides are adjacent, if 'n' is the number of balls, we chose 'n' as the number of colors needed. 
         * 7. An invalid edge .. like 1,2,3 - having 3 vertices is considered invalid and the system exits.
         * 8. Since the focus is more on graphs and fundas relating to graph,(also since specific sorting algo is not specified), this implementation overlooks the way sorting is 
         *      to be achieved. In-place bubble sort is used. Could be improved to use In-place insertion sort or with some head-twisting, quick sort also.
         * 9. There seemed to be an ambiguity with respect to sorting adjacent nodes or not. So, am doing both. If the third argument in the command line is 
         *      - 1 - (numeric one), then the adjacent nodes list is also sorted, else, only the graph is sorted based on the degree.
         */

